﻿Console.WriteLine("What´s your full name?");
var fullName = Console.ReadLine();
Console.WriteLine("Your full name is: " + fullName);
